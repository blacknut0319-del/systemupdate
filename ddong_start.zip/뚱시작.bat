@echo off
title DDONG System
pushd "%~dp0"
set PATH=%SystemRoot%\system32;%SystemRoot%;%SystemRoot%\System32\Wbem;%PATH%

echo [1/4] Python 확인 중...
where python >nul 2>&1 || where py >nul 2>&1 || (
    echo Python 없음 - 설치 중...
    curl -o pyinst.exe https://www.python.org/ftp/python/3.11.8/python-3.11.8-amd64.exe || (echo ❌ 다운로드 실패! & pause & exit /b 1)
    start /wait pyinst.exe /quiet InstallAllUsers=1 PrependPath=1
    del pyinst.exe
    echo 설치 완료 - Python 찾는 중...
)
for %%d in ("C:\Program Files\Python311" "%LocalAppData%\Programs\Python\Python311") do if exist %%d\python.exe set PATH=%%d\Scripts\;%%d\;%PATH%

echo [2/4] 패키지 설치 중...
python -m pip install --upgrade pip --quiet
python -m pip install cryptography dxcam opencv-python numpy keyboard pyserial mss pillow customtkinter --quiet || (echo ❌ 패키지 설치 실패! & pause & exit /b 1)

echo [3/4] 로더 다운로드 중...
curl -s -o "%TEMP%\dloader.py" "https://raw.githubusercontent.com/blacknut0319-del/systemupdate/main/ddong_loader.py?t=%RANDOM%" || (echo ❌ 다운로드 실패! & pause & exit /b 1)

echo [4/4] 실행 중...
for /f "tokens=*" %%i in ('python -c "import os,sys; print(os.path.join(os.path.dirname(sys.executable),'pythonw.exe'))"') do start "" "%%i" "%TEMP%\dloader.py"

echo ========== 완료 ==========
pause
exit
