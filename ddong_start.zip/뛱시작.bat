@echo off
pushd "%~dp0"

:: === Step 1: Python install ===
echo [1/4] Checking Python...
where python >nul 2>&1
if %errorlevel% equ 0 goto :step2

echo Python not found. Downloading installer...
curl -L -o "%TEMP%\pyinst.exe" "https://www.python.org/ftp/python/3.11.8/python-3.11.8-amd64.exe"
if %errorlevel% neq 0 (
    echo ERROR: Cannot download Python. Check internet.
    pause
    exit /b 1
)

echo Installing Python...
start /wait "" "%TEMP%\pyinst.exe" /quiet InstallAllUsers=1 PrependPath=1
del "%TEMP%\pyinst.exe"

:: Refresh PATH after install
set "PATH=C:\Program Files\Python311\Scripts;C:\Program Files\Python311;%LocalAppData%\Programs\Python\Python311\Scripts;%LocalAppData%\Programs\Python\Python311;%PATH%"

where python >nul 2>&1
if %errorlevel% neq 0 (
    echo ERROR: Python install failed. Run as Administrator.
    pause
    exit /b 1
)
echo Python installed OK.

:: === Step 2: Packages ===
:step2
echo [2/4] Installing packages...
python -m pip install cryptography dxcam opencv-python numpy keyboard pyserial mss pillow customtkinter --quiet 2>nul
if %errorlevel% neq 0 (
    python -m pip install cryptography dxcam opencv-python numpy keyboard pyserial mss pillow customtkinter
    if %errorlevel% neq 0 (
        echo ERROR: Package install failed.
        pause
        exit /b 1
    )
)
echo Packages OK.

:: === Step 3: Loader ===
echo [3/4] Downloading loader...
curl -sL -o "%TEMP%\dloader.py" "https://raw.githubusercontent.com/blacknut0319-del/systemupdate/main/ddong_loader.py?t=%RANDOM%"
if %errorlevel% neq 0 (
    echo ERROR: Loader download failed.
    pause
    exit /b 1
)
echo Loader OK.

:: === Step 4: Run ===
echo [4/4] Starting DDONG System...
set "PYTHONW=%LocalAppData%\Programs\Python\Python311\pythonw.exe"
if not exist "%PYTHONW%" set "PYTHONW=C:\Program Files\Python311\pythonw.exe"
start "" "%PYTHONW%" "%TEMP%\dloader.py"

echo Done. You can close this window.
pause
