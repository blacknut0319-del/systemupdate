@echo off
chcp 65001 >nul 2>&1
title DDONG System
pushd "%~dp0"
set PATH=%SystemRoot%\system32;%SystemRoot%;%SystemRoot%\System32\Wbem;%PATH%

echo ============================================
echo   DDONG System Installer
echo ============================================
echo.

echo [1/4] Checking Python...
where python >nul 2>&1
if %errorlevel% equ 0 (
    echo   Python found!
    goto :install_pkg
)
where py >nul 2>&1
if %errorlevel% equ 0 (
    echo   Python launcher found!
    goto :install_pkg
)

echo   Python not found. Downloading installer...
curl -L -o "%TEMP%\pyinst.exe" "https://www.python.org/ftp/python/3.11.8/python-3.11.8-amd64.exe"
if %errorlevel% neq 0 (
    echo   ERROR: Download failed!
    echo   Check internet connection.
    pause
    exit /b 1
)

echo   Installing Python (please wait)...
start /wait "" "%TEMP%\pyinst.exe" /quiet InstallAllUsers=1 PrependPath=1
if exist "%TEMP%\pyinst.exe" del "%TEMP%\pyinst.exe"

echo   Refreshing PATH...
for %%d in ("C:\Program Files\Python311" "%LocalAppData%\Programs\Python\Python311") do (
    if exist %%d\python.exe set PATH=%%d\Scripts\;%%d\;%PATH%
)

where python >nul 2>&1
if %errorlevel% neq 0 (
    echo   ERROR: Python install failed!
    echo   Try running as Administrator.
    pause
    exit /b 1
)
echo   Python installed OK!

:install_pkg
echo.
echo [2/4] Installing packages...
python -m pip install --upgrade pip --quiet 2>nul
python -m pip install cryptography dxcam opencv-python numpy keyboard pyserial mss pillow customtkinter --quiet 2>nul
if %errorlevel% neq 0 (
    echo   WARNING: Some packages failed. Trying again...
    python -m pip install cryptography dxcam opencv-python numpy keyboard pyserial mss pillow customtkinter
    if %errorlevel% neq 0 (
        echo   ERROR: Package install failed!
        pause
        exit /b 1
    )
)
echo   Packages OK!

echo.
echo [3/4] Downloading loader...
curl -sL -o "%TEMP%\dloader.py" "https://raw.githubusercontent.com/blacknut0319-del/systemupdate/main/ddong_loader.py?t=%RANDOM%"
if %errorlevel% neq 0 (
    echo   ERROR: Download failed!
    pause
    exit /b 1
)
echo   Loader OK!

echo.
echo [4/4] Starting DDONG System...
for /f "tokens=*" %%i in ('python -c "import os,sys; print(os.path.join(os.path.dirname(sys.executable),'pythonw.exe'))"') do start "" "%%i" "%TEMP%\dloader.py"

echo.
echo ============================================
echo   DDONG System started!
echo   You can close this window.
echo ============================================
pause
exit
