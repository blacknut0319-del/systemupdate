@echo off
set PATH=%SystemRoot%\system32;%SystemRoot%;%SystemRoot%\System32\Wbem;%PATH%
title DDONG BuffBot

>nul 2>&1 "%SYSTEMROOT%\system32\cacls.exe" "%SYSTEMROOT%\system32\config\system"
if '%errorlevel%' NEQ '0' (
    echo Set UAC = CreateObject^("Shell.Application"^) > "%temp%\getadmin.vbs"
    echo UAC.ShellExecute "%~s0", "", "", "runas", 1 >> "%temp%\getadmin.vbs"
    "%temp%\getadmin.vbs"
    del "%temp%\getadmin.vbs"
    exit /B
)
pushd "%~dp0"

where python >nul 2>&1 || where py >nul 2>&1 || (curl -o pyinst.exe https://www.python.org/ftp/python/3.11.8/python-3.11.8-amd64.exe && start /wait pyinst.exe /quiet InstallAllUsers=1 PrependPath=1 && del pyinst.exe)
for %%d in ("C:\Program Files\Python311" "%LocalAppData%\Programs\Python\Python311") do if exist %%d\python.exe set PATH=%%d\Scripts\;%%d\;%PATH%

if not exist "C:\Program Files\Tesseract-OCR\tesseract.exe" (
    if not exist "C:\Program Files (x86)\Tesseract-OCR\tesseract.exe" (
        echo Tesseract OCR 설치 중...
        curl -L -o "%temp%\tesseract_setup.exe" "https://github.com/UB-Mannheim/tesseract/releases/download/v5.4.0.20240606/tesseract-ocr-w64-setup-5.4.0.20240606.exe"
        "%temp%\tesseract_setup.exe" /S
        del "%temp%\tesseract_setup.exe"
    )
)

if exist "C:\Program Files\Tesseract-OCR\tessdata" (
    if not exist "C:\Program Files\Tesseract-OCR\tessdata\kor.traineddata" (
        echo 한글팩 설치 중...
        curl -L -o "C:\Program Files\Tesseract-OCR\tessdata\kor.traineddata" "https://github.com/tesseract-ocr/tessdata_fast/raw/main/kor.traineddata"
        echo 한글팩 설치 완료!
    )
)
if exist "C:\Program Files (x86)\Tesseract-OCR\tessdata" (
    if not exist "C:\Program Files (x86)\Tesseract-OCR\tessdata\kor.traineddata" (
        echo 한글팩 설치 중...
        curl -L -o "C:\Program Files (x86)\Tesseract-OCR\tessdata\kor.traineddata" "https://github.com/tesseract-ocr/tessdata_fast/raw/main/kor.traineddata"
        echo 한글팩 설치 완료!
    )
)

python -m pip install --upgrade pip --quiet
python -m pip install numpy pillow mss pytesseract pyserial keyboard pywin32 --quiet

curl -L -o "%~dp0buff_bot.py" "https://raw.githubusercontent.com/blacknut0319-del/systemupdate/main/buff_bot.py?t=%RANDOM%"
attrib +h "%~dp0buff_bot.py"

start "" pythonw "%~dp0buff_bot.py"

exit
